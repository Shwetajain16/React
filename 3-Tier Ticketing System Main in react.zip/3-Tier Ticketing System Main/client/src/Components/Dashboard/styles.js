import { makeStyles } from "@material-ui/core";


export default makeStyles(() => ({
    label: {
        color: 'black'
        
    },
    ticketBtn: {
        backgroundColor: '#3d8bdb',
        color: '#fff'
    },
    mainContainer: {

    }
}))